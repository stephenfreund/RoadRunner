def f(x):
    [x for x in x] = x
