print type(KeyError())
