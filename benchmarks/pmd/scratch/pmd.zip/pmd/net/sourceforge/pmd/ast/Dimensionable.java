package net.sourceforge.pmd.ast;

public interface Dimensionable {
    public boolean isArray();

    public int getArrayDepth();
}
