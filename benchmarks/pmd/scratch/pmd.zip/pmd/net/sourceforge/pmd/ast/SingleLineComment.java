package net.sourceforge.pmd.ast;

public class SingleLineComment extends Comment {

    public SingleLineComment(Token t) {
        super(t);
    }

}
